<?php 
require_once('php/head.php');
?>

<div id="mian" class="container">
<div style="max-width:500px; margin:0 auto; text-align:center;" class="panel panel">
    <div class="panel-body">
      	<div id="kon"></div>
    	<h4>请求的页面不存在或已被删除</h4>
    	<a class="btn btn-link" href="index.php" role="button">返回首页</a>
    </div>
</div>
</div>